// app.js
var _openid = '';
var _session_key = '';
var _code = '';
// const APP_ID = 'wx003d7862cd8a0384';//anni
// const APP_SECRET = 'b8bd8d854108dda6d9e3f08c54196991';//anni
// var APP_ID = 'wx31d64bf834fd4c52';//zhang
// var APP_SECRET = '59be388e1ebeecd6fdbdfca4b7003294';//zhang
// var APP_ID = 'wxdeb784911d26ba23';//优选大米
// var APP_SECRET = '0e4c43c2b80c7e1219f0d234c64ed42d';//优选大米
var APP_ID = 'wx4f3931702e48934a';//婉辞
var APP_SECRET = '8613376f9c61fb97686394eee2fdd924'//婉辞
var nickName = ''
var avatarUrl = ''
App({
  onLaunch: function () {
    var jtappid = ''
    var that = this
    that.APP_ID = APP_ID
    that.APP_SECRET = APP_SECRET
    // that.jtappid = 'JT20170914160714642'//zhang
    // that.jtappid = 'JT201709251030119718'//优选大米
    that.jtappid = 'JT201710111415434441'//婉辞
    // that.jtappid = 'JT201709132050416254'
    //调用登录接口
    wx.login({
      success: function (res) {
        that._code = res.code;
        wx.request({
          //获取openid接口
          url: 'https://sz800800.cn/index.php/Wxpay/get_user_info',
          data: {
            code: res.code,
            appid: APP_ID,
            secret: APP_SECRET
          },
          method: 'post',
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            var data = JSON.parse(res.data)
            that._openid = data.openid
            that._session_key = data.session_key
            
          }
        }),
          wx.getUserInfo({
            success: function (res) {
              that.nickName = res.userInfo.nickName;
              that.avatarUrl = res.userInfo.avatarUrl;
            }
          });
      },
    });
  }
});





