var app = getApp();
var searchValue =''
// pages/search/search.js
Page({
  data: {
    hotKeyShow: true,
    historyKeyShow: true,
    searchValue: 111,
    page: 0,
    productData: [],
    historyKeyList: [],
    hotKeyList: [],
    search_store:''
  },
  onLoad: function (options) {
    searchValue = options.searchValue;
    var program_id = app.jtappid;
    var that = this;
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/index_search',
      method: 'post',
      data: { str: searchValue, program_id: program_id },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log("aaa:" + JSON.stringify(res.data))
        that.setData({
          search_store: res.data,
          searchValue: searchValue
        });
      },
      fail: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      },
    })
  },
  searchValueInput: function (e) {
    var value = e.detail.value;
    this.setData({
      searchValue: value,
    });
    if (!value && this.data.productData.length == 0) {
      this.setData({
        hotKeyShow: true,
        historyKeyShow: true,
      });
    }
  },
  suo:function(){
    var program_id = app.jtappid;
    var that = this;
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/index_search',
      method: 'post',
      data: { str: that.data.searchValue, program_id: program_id },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log("aaa:" + JSON.stringify(res.data))
        that.setData({
          search_store: res.data,
        });
      },
      fail: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      },
    });
  }

});