var app = getApp();
// pages/cart/cart.js
Page({
  data: {
    page: 1,
    minusStatuses: ['disabled', 'disabled', 'normal', 'normal', 'disabled'],
    total: 0,
    carts: [],
    buy_num:''
  },
  onShow: function () {
    this.onLoad()
  },
  //页面加载
  onLoad: function (options) {
    var that = this
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/shopping_car02',
      method: 'GET',
      data: {
        openid: app._openid,
        program_id: app.jtappid
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        // console.log("购物车res：" + JSON.stringify(res.data.k1))
        // // 购物车数据
        // var carts = res.data;
        // 将数值与状态写回
        that.setData({
          carts: res.data.k1
        });
        that.sum();
      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    });
  },
  /*绑定点击事件，将checkbox样式改变为选中与非选中*/
  bindCheckbox: function (e) {
    //拿到下标值，以在carts作遍历指示用
    var index = parseInt(e.currentTarget.dataset.index);
    //原始的icon状态
    var selected = this.data.carts[index].selected;
    var carts = this.data.carts;
    // 对勾选状态取反
    carts[index].selected = !selected;
    // 写回经点击修改后的数组
    this.setData({
      carts: carts
    });
    this.sum()
  },
  // 环境中目前已选状态
  bindSelectAll: function () {
    var selectedAllStatus = this.data.selectedAllStatus;
    // 取反操作
    selectedAllStatus = !selectedAllStatus;
    // 购物车数据，关键是处理selected值
    var carts = this.data.carts;
    // 遍历
    for (var i = 0; i < carts.length; i++) {
      carts[i].selected = selectedAllStatus;
    }
    this.setData({
      selectedAllStatus: selectedAllStatus,
      carts: carts
    });
    this.sum()
  },
  // 立即结算（下单）
  bindCheckout: function () {
    var toastStr = '';
    // 遍历取出已勾选的cid
    for (var i = 0; i < this.data.carts.length; i++) {
      if (this.data.carts[i].selected) {
        toastStr += this.data.carts[i].id;
        toastStr += ',';
      }
    }
    // console.log("toastStr:" + JSON.stringify(toastStr))
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/build_order',
      data: {
        array_id: toastStr,
        openid: app._openid,
        program_id: app.jtappid
      },
      header: { 'content-type': 'application/x-www-form-urlencoded' },
      method: 'GET',
      dataType: '',
      success: function (res) {
        // console.log("JSON.stringify(res.data):" + JSON.stringify(res.data))
        let shangping = JSON.stringify(res.data)
        let k1 = res.data.k1
        if(toastStr == '') {
          wx.showToast({
            title: '请选择要结算的商品！',
            duration: 2000
          });
          return false;
        }
        //存回data
        if (k1 == null) {
            wx.navigateTo({
              url: '../address/user-address/user-address',
            })
          }else{
            wx.navigateTo({ 
              url: '../order/pay?toastStr=' + toastStr+'&shangping=' + shangping,
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { },
    })


  },
 // 计算总金额
  sum: function () {
    var carts = this.data.carts;
    var total = 0;
    for (var i = 0; i < carts.length; i++) {
      if (carts[i].selected) {
        total += carts[i].buy_num * carts[i].price_sell;
      }
    }
    // 写回经点击修改后的数组
    this.setData({
      carts: carts,
      total: '¥ ' + total
    });
  },
  //自减
  bindMinus: function (e) {
    var that = this;
    var index = parseInt(e.currentTarget.dataset.index);
    var cart_id = e.currentTarget.dataset.cartid;
    var buy_num = that.data.carts[index].buy_num;
    // 如果只有1件了，就不允许再减了
    if (buy_num > 1) {
     
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/goods_add2',
      method: 'post',
      data: {
        id: cart_id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        // 购物车数据
        var carts = that.data.carts;
        carts[index].buy_num = buy_num;
        console.log("buy_num--:" + JSON.stringify(buy_num))
        // 只有大于一件的时候，才能normal状态，否则disable状态
        var minusStatus = buy_num <= 1 ? 'disabled' : 'normal';
        // 按钮可用状态
        var minusStatuses = that.data.minusStatuses;
        minusStatuses[index] = minusStatus;
        if(res.data.status==1){
        // 将数值与状态写回
        that.setData({
          buy_num: --buy_num,
          minusStatuses: minusStatuses
          });
        }
        that.sum();
        that.onLoad()
      }
    })
    
    } else if (buy_num == 1) {
      that.removeShopCard(e)
      return false
    }
  },
  //自增
  bindPlus: function (e) {
    var that = this;
    var index = parseInt(e.currentTarget.dataset.index);
    var buy_num = that.data.carts[index].buy_num;
    
    console.log("buy_num++:" + buy_num);
    var cart_id = e.currentTarget.dataset.cartid;
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/goods_add01',
      method: 'post',
      data: {
        id: cart_id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },

      success: function (res) {
        console.log('自增：' + JSON.stringify(res.data))
        var status = res.data.status;
        if (status == 1) {
          // 只有大于一件的时候，才能normal状态，否则disable状态
          var minusStatus = buy_num <= 1 ? 'disabled' : 'normal';
          // 购物车数据
          var carts = that.data.carts;
          carts[index].buy_num = buy_num;
          var minusStatuses = that.data.minusStatuses;
          minusStatuses[index] = minusStatus;
          // 将数值与状态写回
          that.setData({
            buy_num: ++buy_num,
            minusStatuses: minusStatuses
          });
          that.sum();
          that.onLoad()
        } else {
          wx.showToast({
            title: '操作失败！',
            duration: 2000
          });
        }
      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    });
  },
  //移除
  removeShopCard: function (e) {
    var that = this;
    var cardId = e.currentTarget.dataset.cartid;
    wx.showModal({
      title: '提示',
      content: '你确认移除吗',
      success: function (res) {
        res.confirm && wx.request({
          url: 'https://sz800800.cn/pg.php/Index/delete_buy_car',
          method: 'post',
          data: {
            id: cardId,
          },
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            //--init data
            var data = res.data;
            console.log("移除：" + JSON.stringify(res.data))
            if (data.status == 1) {
              wx.showToast({
                title: '移除成功！',
                duration: 2000
              });
              that.sum();
              that.onLoad();
              //that.data.productData.length =0;
              // that.loadProductData();
            } else {
              wx.showToast({
                title: '操作失败！',
                duration: 2000
              });
            }
          },
        });
      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    });
  },
})