var app = getApp();
Page({
  data: {
    // text:"这是一个页面"  
    toast1Hidden: true,
    modalHidden: true,
    modalHidden2: true,
    notice_str: '',
    index: 0
  },
  toast1Change: function (e) {
    this.setData({ toast1Hidden: true });
  },
  //弹出确认框  
  modalTap: function (e) {
    this.setData({
      modalHidden: false
    })
  },
  confirm_one: function (e) {
    console.log(e);
    this.setData({
      modalHidden: true,
      toast1Hidden: false,
      notice_str: '确认成功'
    });
  },
  cancel_one: function (e) {
    console.log(e);
    this.setData({
      modalHidden: true,
      toast1Hidden: false,
      notice_str: '取消成功'
    });
  },
  //弹出提示框  
  modalTap2: function (e) {
    this.setData({
      modalHidden2: false
    })
  },
  modalChange2: function (e) {
    this.setData({
      modalHidden2: true
    })
  },

  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数  
  },
  formSubmit: function (e) {
    var that = this;
    var formData = e.detail.value;
    var tel = e.detail.value.tel;
    if (tel.length == 0) {
      wx.showToast({
        title: '请输入手机号！',
        icon: 'success',
        duration: 1500
      })
      return false;
    }
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (!myreg.test(tel)) {
      wx.showToast({
        title: '手机号有误！',
        icon: 'success',
        duration: 1500
      })
      return false;
    }
    wx.request({
      url: 'https://sz800800.cn/pg.php/person/tire_phpone?openid=' + app._openid,
      data: formData,
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        var that = this
        console.log(res.data)
        if(res.data.status === 1){
          wx.showToast({
            title: '绑定成功',
            duration: 2000
          });
          setTimeout(function () {
            wx.switchTab({
              url: '../user/user',
            })
          }.bind(this), 2000)
        }else{
          wx.showToast({
            title: '绑定失败',
            duration: 2000
          });
        }
      },
      fail: function(res){
        console.log(res)
        wx.showToast({
          title: '绑定失败',
          duration: 2000
        });
      }
    })
  },

  formReset: function () {
    console.log('form发生了reset事件');
    this.modalTap2();
  },
  
})  