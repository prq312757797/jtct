// pages/address/user-address/user-address.js
var app = getApp()
Page({
  data: {
    address: [],
    radioindex: '',
    pro_id:0,
    num:0,
    cartId:0,
    isChecked: false
  },
  onShow:function(){
    this.onLoad()
  },
  onLoad: function () {
    var that = this;
    // 页面加载
    wx.request({
      url: 'https://sz800800.cn/pg.php/person/address',
      data: {
        program_id: app.jtappid,
        openid: app._openid
      },
      header: {// 设置请求的 header
        'Content-Type':  'application/x-www-form-urlencoded'
      },
      success: function (res) {
        // console.log('address:' + JSON.stringify(res.data))
        // success
        var address = res.data;
        // console.log(address);
        if (address == '') {
          var address = []
        }
        that.setData({
          address: address,
        })
      }
    })
    
  },
  setDefault: function(e) {
    var that = this;
    var addrId = e.currentTarget.dataset.id;
    wx.request({
      url: 'https://sz800800.cn/pg.php/person/set_default',
      data: {
        id:addrId
      },
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {// 设置请求的 header
        'content-type':  'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var status = res.data.status;
        if (status==1){
          wx.showToast({
            title: '设置成功！',
            duration: 2000
          });
          that.onLoad();
          // if (cartId) {
          //   wx.redirectTo({
          //     url: '../../order/pay?cartId=' + cartId,
          //   });
        }
      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    })
  },
  //删除
  delAddress: function (e) {
    var that = this;
    var addrId = e.currentTarget.dataset.id;
    console.log("yichu:" + addrId)
    wx.showModal({
      title: '提示',
      content: '你确认移除吗',
      success: function(res) {
        res.confirm && wx.request({
          url:'https://sz800800.cn/pg.php/Person/address_del',
          data: {
            id: addrId
          },
          method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
          header: {// 设置请求的 header
            'Content-Type':  'application/x-www-form-urlencoded'
          },
          success: function (res) {
            console.log(JSON.stringify(res.data))
            // success
            var status = res.data.status;
            if(status==1){
              that.onLoad();
            }else{
              wx.showToast({
                title: res.data.msg,
                duration: 2000
              });
            }
          },
          fail: function () {
            // fail
            wx.showToast({
              title: '网络异常！',
              duration: 2000
            });
          }
        });
      }
    });

  },
  // DataonLoad: function () {
  //   var that = this;
  //   // 页面初始化 options为页面跳转所带来的参数
  //   wx.request({
  //     url: app.d.ceshiUrl + '/Api/Address/index',
  //     data: {
  //       user_id:app.d.userId,
  //     },
  //     method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
  //     header: {// 设置请求的 header
  //       'Content-Type':  'application/x-www-form-urlencoded'
  //     },
      
  //     success: function (res) {
  //       // success
  //       var address = res.data.adds;
  //       if (address == '') {
  //         var address = []
  //       }
  //       that.setData({
  //         address: address,
  //       })
  //     },
  //     fail: function () {
  //       // fail
  //       wx.showToast({
  //         title: '网络异常！',
  //         duration: 2000
  //       });
  //     }
  //   })
  // },
  bianji_to:function(e){
    var addrId = e.currentTarget.dataset.id;
    console.log('收货地址编辑：' + addrId)
    wx.redirectTo({
      url: "../address?id=" + addrId
    })
  }
})