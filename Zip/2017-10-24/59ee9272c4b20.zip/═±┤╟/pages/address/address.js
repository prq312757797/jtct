//城市选择
var app = getApp();
var address = require('../../utils/city.js')
var animation
Page({
  data: {
    man_shouhuo:'',
    id: '',
    man_address: '',
    man_area: '',
    man_phone: '',
    program_id: app.jtappid,
    openid: '',
    menuType: 0,
    begin: null,
    status: 1,
    end: null,
    isVisible: false,
    animationData: {},
    animationAddressMenu: {},
    addressMenuIsShow: false,
    value: [0, 0, 0],
    provinces: [],
    citys: [],
    areas: [],
    province: '',
    city: '',
    area: ''
  },
  //提交表单添加收货地址
  formSubmit: function (e) {
    var that = this
    var adds = e.detail.value;
    var tel = e.detail.value.man_phone;
    if (tel.length == 0) {
      wx.showToast({
        title: '请输入手机号！',
        icon: 'success',
        duration: 1500
      })
      return false;
    }
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (!myreg.test(tel)) {
      wx.showToast({
        title: '手机号有误！',
        icon: 'success',
        duration: 1500
      })
      return false;
    }
    wx.request({
      url: 'https://sz800800.cn/pg.php/person/address_add',
      data: adds,
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {// 设置请求的 header
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log('添加收货地址:' + JSON.stringify(res.data))
        if (res.data.status == 1) {
          wx.showToast({
            title: '保存成功',
            duration: 2000
          });
          wx.navigateBack({
            delta: 2
          })
        } else {
          wx.showToast({
            title: '保存失败，请稍后再试···',
            duration: 2000
          });
          return false;
        }
      },
    })
  },
  //编辑表单收货地址
  form: function (e) {
    var addss = e.detail.value;
    console.log(JSON.stringify(addss))
    var tel = e.detail.value.man_phone;
    if (tel.length == 0) {
      wx.showToast({
        title: '请输入手机号！',
        icon: 'success',
        duration: 1500
      })
      return false;
    }
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (!myreg.test(tel)) {
      wx.showToast({
        title: '手机号有误！',
        icon: 'success',
        duration: 1500
      })
      return false;
    }
    wx.request({
      url: 'https://sz800800.cn/pg.php/person/address_sv',
      data: addss,
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {// 设置请求的 header
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(JSON.stringify(res.data))
        if (res.data.status == 1) {
          wx.showToast({
            title: '修改成功！',
            duration: 2000
          });
          wx.navigateBack({
            delta: 1
          })
        }else{
          wx.showToast({
            title: '操作失败！',
            duration: 2000
          });
        }
      }
    })
  },
  onLoad: function (options) {
    // 生命周期函数--监听页面加载
    // 默认联动显示北京
    var that = this;
    var cartId = options.id;
    that.setData({
      openid: app._openid,
      cartId: options.cartId
    })
    if (cartId != 0) {
      wx.request({
        url: 'https://sz800800.cn/pg.php/person/address_info?id=' + cartId,
        header: {// 设置请求的 header
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log("res:"+JSON.stringify(res.data))
          if (res.data != null){
            that.setData({
              man_shouhuo: res.data.man_shouhuo,
              man_phone: res.data.man_phone,
              man_area: res.data.man_area,
              man_address: res.data.man_address,
              id: res.data.id
            })
          }
        },
        fail: function () {
          // fail
          wx.showToast({
            title: '网络异常！',
            duration: 2000
          });
        },
      })
    }
    // 初始化动画变量
    var animation = wx.createAnimation({
      duration: 500,
      transformOrigin: "50% 50%",
      timingFunction: 'ease',
    })
    this.animation = animation;
    // 默认联动显示北京
    var id = address.provinces[0].id
    this.setData({
      provinces: address.provinces,
      citys: address.citys[id],
      areas: address.areas[address.citys[id][0].id],
    })
  },
  // 选择状态按钮
  selectState: function (e) {
    console.log('selectState1')
    this.startAnimation(false, -200)
    var status = e.currentTarget.dataset.status
    this.setData({
      status: status
    })

  },
  // 点击所在地区弹出选择框
  selectDistrict: function (e) {
    var that = this
    console.log('111111111')
    if (that.data.addressMenuIsShow) {
      return
    }
    that.startAddressAnimation(true)
  },
  // 执行动画
  startAddressAnimation: function (isShow) {
    console.log(isShow)
    var that = this
    if (isShow) {
      that.animation.translateY(0 + 'vh').step()
    } else {
      that.animation.translateY(40 + 'vh').step()
    }
    that.setData({
      animationAddressMenu: that.animation.export(),
      addressMenuIsShow: isShow,
    })
  },
  // 点击地区选择取消按钮
  cityCancel: function (e) {
    this.startAddressAnimation(false)
  },
  // 点击地区选择确定按钮
  citySure: function (e) {
    var that = this
    var city = that.data.city
    var value = that.data.value
    that.startAddressAnimation(false)
    // 将选择的城市信息显示到输入框
    var areaInfo = that.data.provinces[value[0]].name + ',' + that.data.citys[value[1]].name + ',' + that.data.areas[value[2]].name
    that.setData({
      areaInfo: areaInfo,
    })
  },
  hideCitySelected: function (e) {
    console.log(e)
    this.startAddressAnimation(false)
  },
  // 处理省市县联动逻辑
  cityChange: function (e) {
    console.log(e)
    var value = e.detail.value
    var provinces = this.data.provinces
    var citys = this.data.citys
    var areas = this.data.areas
    var provinceNum = value[0]
    var cityNum = value[1]
    var countyNum = value[2]
    if (this.data.value[0] != provinceNum) {
      var id = provinces[provinceNum].id
      this.setData({
        value: [provinceNum, 0, 0],
        citys: address.citys[id],
        areas: address.areas[address.citys[id][0].id],
      })
    } else if (this.data.value[1] != cityNum) {
      var id = citys[cityNum].id
      this.setData({
        value: [provinceNum, cityNum, 0],
        areas: address.areas[citys[cityNum].id],
      })
    } else {
      this.setData({
        value: [provinceNum, cityNum, countyNum]
      })
    }
  },

})