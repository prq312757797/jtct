// pages/index/log.js
var app = getApp();
Page({
  data: {
    time:3,
    img:''
  },
  onLoad: function (options) {
    var that = this
    var time = 3
    var a_time = ''
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/wellcome',
      method: 'get', 
      data: {
        program_id: app.jtappid
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        that.setData({
          img:res.data
        });
      }
    })
    setTimeout(function () {
      a_time = --time
      wx.switchTab({
        url: '../../index/index',
        success: function (res) { },
        fail: function (res) {},
      })
      that.setData({
        time: a_time
      })
    }.bind(this), 2000)
    setTimeout(function () {
      a_time = --time
      that.setData({
        time: a_time
      })
    }.bind(this), 2000)
    setTimeout(function () {
      a_time = --time
      that.setData({
        time: a_time
      })
    }.bind(this), 2900)
    setTimeout(function () {
    }.bind(this), 3000)
  },
  onReady: function () {
  },
  onShow: function () {
  },
  onHide: function () {
  },
  onUnload: function () {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log('下拉动作执行了')
    this.onLoad()
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log('上拉动作执行了')
    this.onLoad()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})