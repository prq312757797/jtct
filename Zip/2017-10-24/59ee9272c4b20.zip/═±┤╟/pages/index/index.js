var app = getApp();
var util = require("../../utils/util.js")
var head = ''
var name = ''
Page({
  data: {
    from_id: '',
    scene: '',
    lunbo: {
      imgUrls: [],
      indicatorDots: true,
      autoplay: true,
      interval: 5000,
      duration: 1000,
      circular: true,
    },
    video:[],
    store_logos: [],
    store_sliding: [],
      advertising1: [],
      advertising2: [],
      advertising3:[],
    store_gongge: [],
    jiugongge_img: [],
    switchTab: 'navigateTo',
    top_url: '?program_id=' + app.jtappid,
    searchValue: ''
  },
  onPullDownRefresh() {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    var onPullDownRefresh = true;
    this.loadData(onPullDownRefresh)
  },
  loadData: function (onPullDownRefresh) {
    var that = this
    var url = util.apiUrl + 'Index/index_show?session_key=' + app._session_key + "&openid=" + app._openid + "&program_id=" + app.jtappid + "&nickname=" + app.nickName + "&head=" + app.avatarUrl;
    util.request(url, 'post', '', '正在加载数据', function (res) {
      wx.setStorageSync('fenxiao', res.data.k7.text)
      var lunbo_imgUrls = 'lunbo.imgUrls'
      var store_logo1 = new Array();
      var store_logo2 = new Array();
      var store_logos = res.data.k3;
      var advertising1 = new Array();
      var advertising2 = new Array();
      var advertising3 = new Array();
      var store_sliding = new Array();
      var store_sliding_arr = res.data.k4.f1
      var nArr = [];
      for (var i in store_sliding_arr) {
        nArr.push(store_sliding_arr[i]);
      }  
      var store_logos = res.data.k3;
      var advertising = res.data.k2;
      store_sliding = nArr.slice(0, 4);
      store_logo1 = store_logos.slice(0, 4);
      store_logo2 = store_logos.slice(4, 8);
      advertising1 = advertising.slice(0, 1);
      advertising2 = advertising.slice(1, 2);
      advertising3 = advertising.slice(2, 3);
      for (var i = 0; i < res.data.k1.length; i++) {
        res.data.k1[i].url = res.data.k1[i].url.split("?"); //字符分割 
      }
      for (var i = 0; i < res.data.k3.length; i++) {
        res.data.k3[i].url = res.data.k3[i].url.split("?"); //字符分割 
      };
      for (var i = 0; i < res.data.k2.length; i++) {
        res.data.k2[i].url = res.data.k2[i].url.split("?"); //字符分割 
      };
      that.setData({
        video: res.data.k8.video,
        [lunbo_imgUrls]: res.data.k1,
        advertising1: advertising1,
        advertising2: advertising2,
        advertising3: advertising3,
        store_logos: store_logo1,
        store_logo2: store_logo2,
        store_sliding: store_sliding,
        jiugongge_img: res.data.k4.f3,
        store_gongge: res.data.k4.f2,
        duotianpu: res.data.k6,
      });
      that.setData({
        list_data: res
      })
      if (onPullDownRefresh) {
        wx.hideNavigationBarLoading() //完成停止加载
        wx.stopPullDownRefresh() //停止下拉刷新
      }
    }, function (err) {
      wx.showToast({
        title: '加载数据失败',
      })
    })
  },
  onLoad: function (options) {
    var that = this
    if (options.from_id) {
      wx.setStorageSync('from_id', options.from_id)
      that.setData({
        from_id: options.from_id,
      })
    } else {
      wx.setStorageSync('from_id', 0)
    }
    this.loadData()
  },
  //获取搜索框的值
  searchValueInput: function (e) {
    var value = e.detail.value;
    this.setData({
      searchValue: value,
    });
  },
  // 提交
  formSubmit: function (e) {
    var that = this;
    var openid = app._openid
    var formData = e.detail.value;
    console.log(formData)
    console.log(openid)
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/man_contect',
      data: formData,
      header: { 'Content-Type': 'application/json' },
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 1) {
          wx.showToast({
            title: '提交成功',
          })
        }else{
          wx.showToast({
            title: '提交失败',
          })
        }
      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: '小程序开发',
      path: '/pages/index/index',
      success: function (res) {
        wx.showToast({
          title: '分享成功！',
          duration: 5000
        });
        // 分享成功
      },
      fail: function (res) {
        wx.showToast({
          title: '分享失败！',
          duration: 5000
        });
        // 分享失败
      }
    }
  },
  //跳转商品列表页   
  listdetail: function (e) {
    wx.navigateTo({
      url: '../listdetail/listdetail?title=' + e.currentTarget.dataset.title,
    })
  },
  //跳转商品搜索页  
  suo: function (e) {
    wx.navigateTo({
      url: '../search/search?searchValue=' + this.data.searchValue,
    })
  },
});
  //点击加载更多
  // getMore: function (e) {
  //   var that = this;
  //   var page = that.data.page;
  //   wx.request({
  //     url: app.d.ceshiUrl + '/Api/Index/getlist',
  //     method: 'post',
  //     data: { page: page },
  //     header: {
  //       'Content-Type': 'application/x-www-form-urlencoded'
  //     },
  //     success: function (res) {
  //       var prolist = res.data.prolist;
  //       if (prolist == '') {
  //         wx.showToast({
  //           title: '没有更多数据！',
  //           duration: 2000
  //         });
  //         return false;
  //       }
  //       //that.initProductData(data);
  //       that.setData({
  //         page: page + 1,
  //         productData: that.data.productData.concat(prolist)
  //       });
  //       //endInitData
  //     },
  //     fail: function (e) {
  //       wx.showToast({
  //         title: '网络异常！',
  //         duration: 2000
  //       });
  //     }
  //   })
  // },