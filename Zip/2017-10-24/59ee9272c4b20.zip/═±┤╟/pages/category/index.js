// import ApiList from  '../../config/api';
// import request from '../../utils/request.js';
//获取应用实例  
var app = getApp();
var fenlai_id =''
Page({
  data: {
    fenlai_id:0,
    // types: null,
    typeTree: {}, // 数据缓存
    postId:0,
    // 当前类型
    "types": [
    ],
    typeTree: [],
  },

  onLoad: function (option) {
    var that = this;
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/goods_fl_list?program_id=' + app.jtappid,
      method: 'get',
      data: {},
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var list = res.data.k1;
        fenlai_id= list[0].id
        var catList = res.data.k2;
        that.setData({
          types: list,
          typeTree: catList
        });
        wx.request({
          url: 'https://sz800800.cn/pg.php/Index/goods_list_ajax',
          method: 'post',
          data: { fenlei_id: fenlai_id, program_id: app.jtappid },
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            // console.log("res:" + JSON.stringify(res.data))
            var catList = res.data;
            that.setData({
              postId: fenlai_id,
              typeTree: catList,
            });
          },
          error: function (e) {
            wx.showToast({
              title: '网络异常！',
              duration: 2000,
            });
          }
        });
      }
    });
  },

  tapType: function (e) {
    var that = this;
    var postId = e.currentTarget.dataset.id;
    that.setData({
      postId: postId
    });
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/goods_list_ajax' ,
      method: 'post',
      data: { fenlei_id: postId, program_id: app.jtappid},
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var catList = res.data;
        that.setData({
          typeTree: catList,
        }); 
      },
      error: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000,
        });
      }
    });
  },
})