// pages/dis_dil/dis_d1.js
var app = getApp();
var util = require("../../utils/util.js")
Page({
  data: {
    list: ''
  },

  tx_mingxi:function(e){
    wx.navigateTo({
      url: './dis_d3',
    })
  },
  onLoad: function (options) {
    var that = this
      var that = this
      var url = 'https://sz800800.cn/pg.php/Dfx/fenxiao_yj?openid=' + app._openid + "&program_id=" + app.jtappid;
      util.request(url, 'get', '', '正在加载数据', function (res) {
        var list = res.data;
        // success
        that.setData({
          list: list
        })
      })  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})