var util = require("../../utils/util.js")
var app = getApp();
Page({
  data: {
    winWidth: 0,
    winHeight: 0,
    tab: 0,
    yiji:0,
    erji: 0,
    sanji: 0
  },
  onLoad: function(){
    this.dataApi();
    this.initSystemInfo();//宽高
  },
  onPullDownRefresh() {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    var onPullDownRefresh = true;
    this.dataApi(onPullDownRefresh)
  },
  dataApi: function (onPullDownRefresh) {
    var that = this
    var url = 'https://sz800800.cn/pg.php/Dfx/offline?openid=' + app._openid + "&program_id=" + app.jtappid;
    util.request(url, 'get', '', '正在加载数据', function (res) {
      console.log(res)
      that.setData({
        yiji: res.data.k1,
        erji: res.data.k2,
        sanji: res.data.k3,
      })
    })
    if (onPullDownRefresh) {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }
    console.log("我的下线加载了")
  },
  tab_slide: function (e) {//滑动切换tab 
    var that = this;
    that.setData({ tab: e.detail.current });
  },
  tab_click: function (e) {//点击tab切换
    var that = this;
    if (that.data.tab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        tab: e.target.dataset.current
      })
    }
  },
  //获取窗口宽高
  initSystemInfo: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },
})