// pages/dis_dil/dis_d5.js
var util = require("../../utils/util.js")
var app = getApp();
Page({
  data: {
    apidata:{},
    scene: ''
  },
  onLoad: function (options) {
    var that = this
    console.log('openid:' + app._openid)
    this.setData({
      scene: 'https://sz800800.cn/pg.php/Qdcode/qd_code?appid=' + app.APP_ID + '&secret=' + app.APP_SECRET + '&openid=' + app._openid + "&program_id=" + app.jtappid
    })
    var url = 'https://sz800800.cn/pg.php/Qdcode/qd_code';
    // util.request('https://sz800800.cn/pg.php/Qdcode/qd_code?appid=' + app.APP_ID + '&secret=' + app.APP_SECRET + '&openid=' + app._openid + "&program_id=" + app.jtappid, 'get', '', '正在加载数据', function (res) {
    //   that.setData({
    //     scene: res
    //   })
    // })
  },
  previewImage: function (e) {
    wx.previewImage({
      urls: this.data.scene.split(',')
      // 需要预览的图片http链接 
    })
  }
})