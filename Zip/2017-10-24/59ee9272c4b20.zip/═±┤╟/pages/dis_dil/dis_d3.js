var util = require("../../utils/util.js")
var app = getApp();
Page({
  data: {
    tab: 0, //默认tab为0    
    data_list: '',
    winWidth: 0,
    winHeight: 0,
    viewShow: false,
    current: 0
  },
  zhankai: function (e) {
    var that = this;
    console.log(e.target.dataset.current)
    this.setData({
      viewShow: !this.data.viewShow
    })
    if (that.data.current === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        current: e.target.dataset.current
      })
    }
  },
  dataApi: function () {
    var that = this
    var url = 'https://sz800800.cn/pg.php/Dfx/tixian?openid=' + app._openid + "&program_id=" + app.jtappid;
    util.request(url, 'get', '', '正在加载数据', function (res) {
      console.log(res)
      that.setData({
        data_list: res.data
      })
    })
  },
  onLoad: function () {
    this.initSystemInfo();//宽高
    this.dataApi()
  },
  tab_slide: function (e) {//滑动切换tab 
    var that = this;
    that.setData({ tab: e.detail.current });
  },
  tab_click: function (e) {//点击tab切换
    var that = this;
    console.log("top:" + e.target.dataset.current)
    if (that.data.tab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        tab: e.target.dataset.current
      })
    }
  },
  //获取窗口宽高
  initSystemInfo: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },
})  