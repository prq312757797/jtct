var util = require("../../utils/util.js")
var app = getApp();
Page({
  data: {
    tab: 0, //默认tab为0    
    data_list: '',
    winWidth: 0,
    winHeight: 0,
    isStatus: 0,
    data_list00: [],
    data_list01: [],
    data_list02: [],
    data_list03: [],
    viewShow: false,
    current: 0
  },
  zhankai: function (e) {
    var that = this;
    console.log(e.target.dataset.current)
    this.setData({
      viewShow: !this.data.viewShow
    })
    if (that.data.current === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        current: e.target.dataset.current
      })
    }
  },
  dataApi: function (onPullDownRefresh) {
    var that = this
    var isStatus = that.data.tab
    var url = 'https://sz800800.cn/pg.php/Dfx/fx_order?openid=' + app._openid + "&program_id=" + app.jtappid + "&state=" + isStatus;
    util.request(url, 'get', '', '正在加载数据', function (res) {
      var list = res.data;
      switch (that.data.tab) {
        case 0:
          that.setData({
            data_list0: res.data,
          })
          break;
        case 1:
          that.setData({
            data_list1: list,
          });
          break;
        case 2:
          that.setData({
            data_list2: list,
          });
          break;
        case 3:
          that.setData({
            data_list3: list,
          });
          break;
      }

    })
    if (onPullDownRefresh) {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }
    console.log("分销订单加载了")
  },
  onPullDownRefresh() {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    var onPullDownRefresh = true;
    this.dataApi(onPullDownRefresh)
  },
  onLoad: function () {
    this.initSystemInfo();//宽高
    this.dataApi()
  },
  tab_slide: function (e) {//滑动切换tab 
    var that = this;
    that.setData({ tab: e.detail.current });
    this.dataApi();
  },
  tab_click: function (e) {//点击tab切换
    var that = this;
    console.log("top:" + e.target.dataset.current)
    if (that.data.tab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        tab: e.target.dataset.current
      })
    }
    this.dataApi();
  },
  //获取窗口宽高
  initSystemInfo: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },
})  