// pages/user/user.js
var app = getApp()
Page( {
  data: {
    userInfo: {},
    orderInfo:{},
    is_show_tire:'',
    dianpu:0
  },
  onShow:function(){
    this.onLoad()
  },
  onLoad: function () {
      var that = this
        //更新数据
        that.setData({
          nickName: app.nickName,
          avatarUrl: app.avatarUrl,
      });
        wx.request({
          url: 'https://sz800800.cn/pg.php/Person/person',
          method: 'get',
          data: {
            program_id: app.jtappid,
            openid: app._openid
          },
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            // console.log("个人中心：" + JSON.stringify(res.data))
            that.setData({
              orderInfo: res.data,
              dianpu: res.data.duoshagnhu.status,
              is_show_tire: res.data.is_show_tire
            });
          }
        });
  },

  //手机解绑
  jiebang: function () {
    var that = this;
    wx.showModal({
      title: '温馨提示',
      content: '您确定要解除手机绑定吗？',
      success: function (res) {
        if (res.confirm) {
          console.log('确定')
          wx.request({
            url: 'https://sz800800.cn/pg.php/person/tire_out_phpone',
            method: 'post',
            data: {
              openid: app._openid
            },
            header: {
              'content-type': 'application/x-www-form-urlencoded'
            },
            success: function (res) {
              if (res.data.status == 1) {
                that.setData({
                  is_show_tire: 1
                });
                wx.showToast({
                  title: '成功解除绑定',
                  duration: 2000
                });
              } else {
                wx.showToast({
                  title: '解除失败，请稍后再试。',
                  duration: 2000
                });
              }
              console.log(res.data)
            }
          });
        } else {
          console.log('取消')
        }

      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: '',
      path: '/pages/index/index',
      success: function (res) {
        // 分享成功
      },
      fail: function (res) {
        // 分享失败
      }
    }
  }
})