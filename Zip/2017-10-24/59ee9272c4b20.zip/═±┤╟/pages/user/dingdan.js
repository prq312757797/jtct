// pages/user/dingdan.js
//index.js  
//获取应用实例  
var wuliu = {"success":true,"reason":"","data":[{"time":"2017-09-29 12:24:52","context":"\u5ba2\u6237 \u7b7e\u6536\u4eba: \u672c\u4eba\u7b7e\u6536 \u5df2\u7b7e\u6536 \u611f\u8c22\u4f7f\u7528\u5706\u901a\u901f\u9012\uff0c\u671f\u5f85\u518d\u6b21\u4e3a\u60a8\u670d\u52a1"},{"time":"2017-09-29 08:15:48","context":"\u3010\u5e7f\u4e1c\u7701\u6df1\u5733\u5e02\u5b9d\u5b89\u533a\u9f99\u534e\u516c\u53f8\u3011 \u6d3e\u4ef6\u4eba: \u8212\u5f3a \u6d3e\u4ef6\u4e2d \u6d3e\u4ef6\u5458\u7535\u8bdd13560729442"},{"time":"2017-09-29 05:03:27","context":"\u3010\u5e7f\u4e1c\u7701\u6df1\u5733\u5e02\u5b9d\u5b89\u533a\u9f99\u534e\u516c\u53f8\u3011 \u5df2\u6536\u5165"},{"time":"2017-09-29 01:18:37","context":"\u3010\u6df1\u5733\u8f6c\u8fd0\u4e2d\u5fc3\u3011 \u5df2\u53d1\u51fa \u4e0b\u4e00\u7ad9 \u3010\u5e7f\u4e1c\u7701\u6df1\u5733\u5e02\u5b9d\u5b89\u533a\u9f99\u534e\u516c\u53f8\u3011"},{"time":"2017-09-29 01:17:17","context":"\u3010\u6df1\u5733\u8f6c\u8fd0\u4e2d\u5fc3\u3011 \u5df2\u6536\u5165"},{"time":"2017-09-28 19:50:38","context":"\u3010\u5e7f\u4e1c\u7701\u6df1\u5733\u5e02\u5b9d\u5b89\u533a\u673a\u573a\u516c\u53f8\u3011 \u5df2\u53d1\u51fa \u4e0b\u4e00\u7ad9 \u3010\u6df1\u5733\u8f6c\u8fd0\u4e2d\u5fc3\u3011"},{"time":"2017-09-28 19:48:25","context":"\u3010\u5e7f\u4e1c\u7701\u6df1\u5733\u5e02\u5b9d\u5b89\u533a\u673a\u573a\u516c\u53f8\u3011 \u5df2\u6536\u4ef6"},{"time":"2017-09-28 17:50:21","context":"\u3010\u5e7f\u4e1c\u7701\u6df1\u5733\u5e02\u5b9d\u5b89\u533a\u673a\u573a\u516c\u53f8\u3011 \u53d6\u4ef6\u4eba: \u674e\u5fb7\u7ea2 \u5df2\u6536\u4ef6"}],"status":6,"exname":"yuantong","ico":"http:\/\/www.kuaidi.com","phone":null,"url":null,"nu":"886543311583751296","company":"\u5706\u901a\u901f\u9012","city":"\u6df1\u5733"}
var app = getApp();
Page({
  data: {
    wuliu: wuliu,
    winWidth: 0,
    winHeight: 0,
    // tab切换  
    currentTab: 0,
    isStatus: 0,
    orderList0: [],
    orderList1: [],
    orderList2: [],
    orderList3: [],
    orderList4: [],
    orderList5: [],
    orderList6: []
  },
  onLoad: function (options) {
    this.initSystemInfo();//宽高
    this.setData({
      currentTab: parseInt(options.currentTab),//数据
      isStatus: options.otype//数据
    });
    this.loadOrderList();
  },
  //加载页面
  loadOrderList: function () {
    var that = this;
    var openid = app._openid;
    var program_id = app.jtappid;
    var isStatus = ++(that.data.isStatus)
    wx.request({
      url: 'https://sz800800.cn/pg.php/Person/order_list',
      method: 'get',
      data: {
        program_id: program_id,
        openid: openid,
        state: isStatus,
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        //--init data        
        var list = res.data;
        switch (that.data.currentTab) {
          case 0:
            that.setData({
              orderList0: list,
            });
            break;
          case 1:
            that.setData({
              orderList1: list,
            });
            break;
          case 2:
            that.setData({
              orderList2: list,
            });
            break;
          case 3:
            that.setData({
              orderList3: list,
            });
            break;
          case 4:
            that.setData({
              orderList4: list,
            });
            break;
          case 5:
            that.setData({
              orderList5: list,
            });
            break;
          case 6:
            that.setData({
              orderList6: list,
            });
            break;
        }
      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      },
    });
 
  },
  //取消订单
  removeOrder: function (e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '提示',
      content: '你确定要取消订单吗？',
      success: function (res) {
        res.confirm && wx.request({
          url: 'https://sz800800.cn/pg.php/Index/quxiao',
          method: 'post',
          data: {
            id: id,
          },
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            // console.log(JSON.stringify(res.data))
            //--init data
            var status = res.data.status;
            if (status == 1) {
              wx.showToast({
                title: '成功取消订单！',
                duration: 2000
              });
              that.loadOrderList();
            } else {
              wx.showToast({
                title: '操作失败，请稍后再试',
                duration: 2000
              });
            }
          },
          fail: function () {
            // fail
            wx.showToast({
              title: '网络异常！',
              duration: 2000
            });
          }
        });

      }
    });
  },

  //获取当前top坐标
  bindChange: function (e) {
    var that = this;
    that.setData({
      currentTab: e.detail.current,
    });
    //没有数据就进行加载
    switch (that.data.currentTab) {
      case 0:
        !that.data.orderList0.length && that.loadOrderList();
        break;
      case 1:
        !that.data.orderList1.length && that.loadOrderList();
        break;
      case 2:
        !that.data.orderList2.length && that.loadOrderList();
        break;
      case 3:
        !that.data.orderList3.length && that.loadOrderList();
        break;
      case 4:
        !that.data.orderList4.length && that.loadOrderList();
        break;
      case 5:
        !that.data.orderList5.length && that.loadOrderList();
        break;
      case 6:
        !that.data.orderList6.length && that.loadOrderList();
        break;
        that.data.orderList6.length = 0;
        that.loadReturnOrderList();
        break;
    }
  },
  //top绑定事件，渲染
  swichNav: function (e) {
    var that = this;
    if (that.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      var current = e.target.dataset.current;
      that.setData({
        currentTab: parseInt(current),
        isStatus: e.target.dataset.otype,
      });
      //没有数据的导航就进行加载
      switch (that.data.currentTab) {
        case 0:
          !that.data.orderList0.length && that.loadOrderList();
          break;
        case 1:
          !that.data.orderList1.length && that.loadOrderList();
          break;
        case 2:
          !that.data.orderList2.length && that.loadOrderList();
          break;
        case 3:
          !that.data.orderList3.length && that.loadOrderList();
          break;
        case 4:
          !that.data.orderList4.length && that.loadOrderList();
          break;
        case 5:
          !that.data.orderList5.length && that.loadOrderList();
          break;
        case 6:
          !that.data.orderList6.length && that.loadOrderList();
          break;
          that.data.orderList6.length = 0;
          that.loadReturnOrderList();
          break;
      }
    };
  },
  //获取窗口宽高
  initSystemInfo: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },
})