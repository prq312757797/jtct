// pages/user/to_my.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    abstract01: '',
    phone_ask: '',
    cs_wx: '',
    cs_qq: '',
    cs_mail: '',
    linkman: '',
    address: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    wx.request({
      url: 'https://sz800800.cn/pg.php/person/aboutus',
      method: 'get',
      data: {
        program_id: app.jtappid,
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var is_show_tire = res.data
        console.log("个人中心：" + JSON.stringify(res.data))
        that.setData({ 
          abstract01: res.data.abstract,
          phone_ask: res.data.phone_ask,
          cs_wx: res.data.cs_wx,
          cs_qq: res.data.cs_qq,
          cs_mail: res.data.cs_mail,
          linkman: res.data.linkman,
          address: res.data.address
        });
      }
    });
  },
  //打电话
  bodaTap: function () {
    wx.makePhoneCall({
      phoneNumber: this.data.phone_ask //仅为示例，并非真实的电话号码
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})