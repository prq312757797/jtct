var app = getApp();
// pages/user/shoucang.js
Page({
  data:{
    page:1,
    productData:[],
  },
  onLoad:function(options){
    this.loadProductData();
  },
  onShow:function(){
    // 页面显示
    this.loadProductData();
  },
  removeFavorites:function(e){
    var that = this;
    var ccId = e.currentTarget.dataset.favId;
    console.log("ccId:" + ccId)
    wx.showModal({
      title: '提示',
      content: '你确认移除吗',
      success: function(res) {
        wx.request({
          url: 'https://sz800800.cn/pg.php/Person/collect_del',
          method:'post',
          data: {
            program_id: app.jtappid,
            openid:app._openid,
            id: ccId
          },
          header: {
            'Content-Type':  'application/x-www-form-urlencoded'
          },
          success: function (res) {
            //--init data
            var data = res.data;
            console.log('aa'+ JSON.stringify(data));
            if(data.status == 1){
              wx.showToast({
                title: '成功移除！',
                duration: 3000
              });
            }else{
              wx.showToast({
                title: '网络异常！',
                duration: 3000
              });
            }
            that.loadProductData();
            //todo
            // if(data.result == 'ok'){
            //   that.data.productData.length =0;
            //   that.loadProductData();
            // }
          },
        });
      }
    });
  },
  loadProductData:function(){
    var that = this;
    wx.request({
      url: 'https://sz800800.cn/pg.php/Person/collect_list',
      method: 'post',
      data: {
        program_id: app.jtappid,
        openid: app._openid
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var data = res.data
        console.log('aa' + JSON.stringify(data));
        //--init data
        that.initProductData(data);

        that.setData({
          productData: res.data,
        });
      },
    });
  },
  initProductData: function (data){
    for(var i=0; i<data.length; i++){
      //console.log(data[i]);
      var item = data[i];

    }
  },
});