var app = getApp();
Page({
  data: {
    input_tixian_num: 0,
    can_tixian: 0,
    openid: '',
    program_id: app.jtappid,
    toast1Hidden: true,
    modalHidden: true,
    modalHidden2: true,
    notice_str: '',
    index: 0
  },
  toast1Change: function (e) {
    this.setData({ toast1Hidden: true });
  },
  //弹出确认框  
  modalTap: function (e) {
    this.setData({
      modalHidden: false
    })
  },
  confirm_one: function (e) {
    console.log(e);
    this.setData({
      modalHidden: true,
      toast1Hidden: false,
      notice_str: '确认成功'
    });
  },
  cancel_one: function (e) {
    console.log(e);
    this.setData({
      modalHidden: true,
      toast1Hidden: false,
      notice_str: '取消成功'
    });
  },
  //弹出提示框  
  modalTap2: function (e) {
    this.setData({
      modalHidden2: false
    })
  },
  modalChange2: function (e) {
    this.setData({
      modalHidden2: true
    })
  },

  onLoad: function (options) {
    this.setData({
      can_tixian: options.can_tixian,
      openid: app._openid
    })
  },
  input_tixian_num: function (e) {
    this.setData({
      input_tixian_num: e.detail.value
    })
  },
  formSubmit: function (e) {
    var that = this;
    var formData = e.detail.value;
    var tel = e.detail.value.tel;
    var a = that.data.tixian_num
    var b = parseFloat(that.data.input_tixian_num)
   
      wx.request({
        url: 'https://sz800800.cn/pg.php/Dfx/tixian',
        data: formData,
        header: {
          'Content-Type': 'application/json'
        },
        success: function (res) {
          var that = this
          console.log(res.data)
          if (res.data.status === 1) {
            wx.showToast({
              title: res.data.msg,
              duration: 2000
            });
            setTimeout(function () {
              wx.navigateBack({
                data: 1
              })
            }.bind(this), 2000)
          } else {
            wx.showToast({
              icon:'fail',
              title: res.data.msg,
              duration: 2000
            });
          }
        }
      })
    
  },

  formReset: function () {
    console.log('form发生了reset事件');
    this.modalTap2();
  },

})  