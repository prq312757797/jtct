// pages/distribution/distribution.js
var util = require("../../utils/util.js")
var app = getApp();
Page({
  data: {
    can_tixian:0,
    tx_btn:'提现',
    fenxiao_zhuangtai:'',
    from_id:'',
    scene:'',
    urldata:'',
    shenqing:false,
    params: {
      openid: app._openid,
      from_id: 0,
      program_id: app.jtappid
    },
  },
  // util.request('https://sz800800.cn/pg.php/Dfx/tixian', 'get', '', '正在加载数据', function (res) {
  //   that.setData({
  //     scene: res.data.k1,
  //     urldata: res.data
  //   })
  // })
  onPullDownRefresh() {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    var onPullDownRefresh = true;
    this.ondata(onPullDownRefresh)
  },
  tx_btn:function(){
    wx.navigateTo({
      url: './btn_tixian/btn_tixian?can_tixian=' + this.data.can_tixian,
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  ondata(onPullDownRefresh){
    console.log('数据重新加载了')
    var that = this
    var url = 'https://sz800800.cn/pg.php/Dfx/fx_index?openid=' + app._openid + "&program_id=" + app.jtappid;
    util.request(url, 'get', '', '正在加载数据', function (res) {
      that.setData({
        scene: res.data.k1,
        urldata:res.data,
        can_tixian: res.data.k1.can_tixian
      })
    })
    if (onPullDownRefresh) {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }
  },
  onLoad: function (options) {
    var that = this
    if (wx.getStorageSync('fenxiao')){
      var fenxiao_zhuangtai = wx.getStorageSync('fenxiao')
      if (fenxiao_zhuangtai == '分销商'){
        this.setData({
          fenxiao_zhuangtai: '正常',
          shenqing: true
        })
      }
    }
    var from_id = 'params.from_id'
    if (wx.getStorageSync('from_id')) {
      that.setData({
        [from_id]: wx.getStorageSync('from_id'),
      })
    }
    this.ondata()
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  // 申请分销
  to_dis: function () {
    var that = this;
    var openid = 'params.openid'
    that.setData({
      [openid]: app._openid
    })
    wx.showModal({
      title: '温馨提示',
      content: '您确定要成为分销商赚更多的钱吗？',
      success: function (res) {
        if (res.confirm) {
          var url = 'https://sz800800.cn/pg.php/Dfx/register'
          util.request(url, 'post', that.data.params, '正在加载数据', function (res) {
            console.log('that.data.params:' + JSON.stringify(res))
            wx.showToast({
              title: '恭喜成为分销商',
            })
            that.setData({
              shenqing:true
            })
          })
        }
      }
    })
  }
})