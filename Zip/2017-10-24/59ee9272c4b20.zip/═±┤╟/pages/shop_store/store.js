// pages/shop_store/shop_store.js
var app = getApp();
var productId = ''
//引入这个插件，使html内容自动转换成wxml内容
var WxParse = require('../../wxParse/wxParse.js');
Page({
  data: {
    markers: [],
    latitude: 0,
    longitude: 0,
    tap2: '',
    tap3: '',
    jiugongge_img: '',
    shouchang: '',
    xiaoliang: '',
    shopInfo: {},
    proList: [],
    tabArr: {
      curHdIndex: 0,
      curBdIndex: 0
    },
    current: 0,
    k1_1: '',
    jianjie: ''
  },
  onLoad: function (option) {
    productId = option.productId;
    var program_id = app.jtappid;
    var that = this

    // 
    wx.request({
      url: 'https://sz800800.cn/pg.php/Dsh/dsh_index',
      data: { id: productId, program_id: program_id },
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function (res) {
        that.setData({
          jiugongge_img: res.data.k1_2,
          k1_1: res.data.k1_1,
          shouchang: res.data.k2,
          xiaoliang: res.data.k3,
        })
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },
  tabFun: function (e) {
    //获取触发事件组件的dataset属性 
    var _datasetId = e.target.dataset.id;
    var _obj = {};
    _obj.curHdIndex = _datasetId;
    _obj.curBdIndex = _datasetId;
    this.setData({
      tabArr: _obj
    });
  },
  tap2: function () {
    var that = this
    wx.request({
      url: 'https://sz800800.cn/pg.php/Dsh/dsh_tj',
      data: { dsh_id: productId, program_id: app.jtappid },
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function (res) {
        that.setData({
          tap2: res.data
        })
      }
    })
  },
  tap3: function () {
    var that = this
    wx.request({
      url: 'https://sz800800.cn/pg.php/Dsh/dsh_xp',
      data: { dsh_id: productId, program_id: app.jtappid },
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function (res) {
        that.setData({
          tap3: res.data
        })
      }
    })
  },
  tap4: function () {
    var that = this
    wx.request({
      url: 'https://sz800800.cn/pg.php/Dsh/profile',
      data: { id: productId, program_id: app.jtappid },
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      // header: {}, // 设置请求的 header
      success: function (res) {
        var sh_jd = new Array(); 
        sh_jd = res.data.sh_jd;
        sh_jd = sh_jd.split(","); 
        var sh_latitude = sh_jd[0]
        var sh_longitude = sh_jd[1]
        that.setData({
          jianjie: res.data,
          latitude: sh_latitude,
          longitude: sh_longitude,
          'markers': [{  
            iconPath: "/images/map.png",
            alpha: 0.5,
            title: res.data.detail_address,
            latitude: sh_latitude,
            longitude: sh_longitude,
            width: 50,
            height: 50
          }],
        })
      }
    })
  },
  //打电话
  bodaTap: function () {
    wx.makePhoneCall({
      phoneNumber: this.data.jianjie.sh_phone //仅为示例，并非真实的电话号码
    })
  },
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
  },
  controltap(e) {
    console.log(e.controlId)
  }

})
