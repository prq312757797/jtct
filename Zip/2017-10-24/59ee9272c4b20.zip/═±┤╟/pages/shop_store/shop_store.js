// pages/shop_store/shop_store.js
var app = getApp();
Page({
  data: {
    icon:'#C0C0C0',
    tip: '',
    program_id: app.jtappid,
    openid:''
  },
  onLoad(){
    console.log('app._openid:' + app._openid)
    this.setData({
      openid:app._openid
    })
  },
  ruzhuxieyi: function (event) {
    var that = this
    wx.showModal({
       title: '入驻协议',
      // \r\n  换行
       content: '这是一个模态弹窗这是一个模态弹窗这是一个模态弹窗这是一个模态弹窗这是一个模态弹窗这是一个模态弹窗这是一个模态弹窗这是一个模态弹窗',
       success: function (res) {
        console.log("res:"+JSON.stringify(res))
          if (res.confirm) {
            that.setData({
              icon: '#00FF00', 
            })
             console.log('用户点击确定')
          }else{
            that.setData({
              icon: '#C0C0C0',
              
            })
            console.log('用户点击取消')
        }
       }
    })
  },
  icon: function(){
    var that = this
    if (this.data.icon == '#C0C0C0'){
      that.setData({
        icon: '#00FF00',
      })
    }else if (this.data.icon == '#00FF00'){
      that.setData({
        icon: '#C0C0C0',
      })
    }
  },
  //POST
  formSubmit: function (e) {
    var adds = e.detail.value;
    //var name2 = e.detail.value.name2;  
    if (this.data.icon == '#00FF00'){
    wx.request({
      url: 'https://sz800800.cn/pg.php/Dsh/dsh_add',
      data: adds,
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {// 设置请求的 header
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res.data)
        if(res.data.status == 1){
          wx.showToast({
            title: '入驻申请已提交！',
            duration: 5000
          });
          wx.navigateBack({
            delta: 1
          })
        }else{
          wx.showToast({
            title: '提交失败！',
            duration: 5000
          });
        }
      }
      })
    } else {
      wx.showToast({
        title: '请阅读入驻申请协议',
        icon: 'loading',
        duration: 3000
      });
     }
    
  },

})
