//index.js  
var util = require("../../utils/util.js")
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
var id = '';
var program_id = app.jtappid;
var openid = app._openid;
var pay_goods_id = '' //点击立即购买以后返回的商品id
var kucun_number = '' //库存数量
Page({
  data: {
    shoucang_status: '',
    k4: '',
    currentTab: 0, //tab切换  
    content: {},
    images: [],
    goods_detail: {},
    article: '',
    itemData: {},
    bannerItem: [],
    // 产品图片轮播
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    buy_num: 1,
  },
  // 传值
  onLoad: function (option) {
    id = option.productId
    var that = this;
    that.loadProductDetail();

  },
  pay_num: function (e) {
    var that = this;
    var buy_num = e.detail.value;
    if (buy_num != that.data.buy_num) {
      wx.request({
        url: 'https://sz800800.cn/pg.php/Index/goods_choose_num',
        method: 'post',
        data: {
          id: pay_goods_id,
          num: buy_num,
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          if (res.data.status == 1) {
            that.setData({
              buy_num: buy_num
            });
          }
        }
      })
    }
  },
  // 商品详情数据获取
  loadProductDetail: function () {
    var that = this;
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/goods_con',
      method: 'get',
      data: {
        id: id,
        program_id: program_id,
        openid: app._openid,
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        kucun_number = res.data.k1.number
        var k2 = new Array();
        k2 = res.data.k2.slice(1, 5);
        var containerTEXT = res.data.k1.goods_content
        var aaa = "/ueditor/php"
        if (containerTEXT) {
          var bbb = containerTEXT.replace(new RegExp(aaa, 'g'), "http://www.sz800800.cn/ueditor/php")
        }
        that.setData({
          images: k2,
          goods_detail: res.data.k1,
          article: WxParse.wxParse('article', 'md', bbb, that, 10),
          content: res.data.k3,
          k4: res.data.k4,
          shoucang_status: res.data.k1.is_collect
        })
      },
      error: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000,
        });
      },
    });
  },
  toast: function () {
    wx.switchTab({
      url: '../cart/cart'
    })
  },
  // 属性选择
  onShow: function () {
  },
  //添加到收藏
  addFavorites: function () {
    var that = this;
    wx.request({
      url: 'https://sz800800.cn/pg.php/GoodsCon/collection01',
      method: 'post',
      data: {
        openid: app._openid,
        program_id: app.jtappid,
        goods_id: id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        if (res.data.status == 1) {
          wx.showToast({
            title: '已收藏！',
            duration: 2000
          });
          that.setData({
            shoucang_status: 1
          })
        } else if (res.data.status == 3) {
          wx.showToast({
            title: '已取消收藏！',
            duration: 2000
          });
          that.setData({
            shoucang_status: 3
          })
        }
        var data = res.data;
        //变成已收藏，但是目前小程序可能不能改变图片，只能改样式
        that.data.itemData = true;

      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    });
  },
  //添加到购物车
  addShopCart: function (e) {
    var that = this;
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/add_buy_car',
      method: 'post',
      data: {
        program_id: program_id,
        openid: app._openid,
        goods_id: id,
      },
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log("加入购物车请求：" + JSON.stringify(res.data.status))
        // //--init data    
        if (res.data.status == 1) {
          wx.showToast({
            title: '加入购物车成功',
            icon: 'success',
            duration: 2000
          });
          that.setData({
            k4: ++that.data.k4,
          })
        } else if (res.data.status == 3) {
          wx.showToast({
            title: '已在购物车',
            icon: 'success',
            duration: 2000
          });
        }
      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      },
    });
  },
  //滑动切换tab 
  slide: function (e) {
    var that = this;
    that.setData({ currentTab: e.detail.current });
  },
  //点击tab切换
  click: function (e) {
    var that = this;
    if (that.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  //确认下单
  lijigoumai: function (e) {
    var that = this
    if (kucun_number > 0) {
      wx.navigateTo({
        url: '../order/pay?pay_goods_id=' + pay_goods_id + ',',
      })
    } else {
      wx.showToast({
        title: '请检查商品库存！',
        icon: 'success',
        duration: 2000
      });
    }
  },
  // 立即购买
  setModalStatus: function (e) {
    var that = this
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    animation.translateY(300).step();

    this.setData({
      animationData: animation.export()
    })
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/add_buy_car',
      method: 'post',
      data: {
        is_pay: 1,
        openid: app._openid,
        program_id: app.jtappid,
        goods_id: id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var a = res.data.status
        if (res.data.status == 1) {
          that.setData(
            {
              showModalStatus: true
            }),
            pay_goods_id = res.data.id
        } else if (res.data.status == 3) {
          wx.showToast({
            title: '已在购物车！',
            duration: 2000
          });
        } else {
          wx.showToast({
            title: '网络异常！',
            duration: 2000
          });
        }
      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    }),
      setTimeout(function () {
        animation.translateY(0).step()
        this.setData({
          animationData: animation
        })
        if (e.currentTarget.dataset.status == 0) {
          this.setData(
            {
              showModalStatus: false
            }
          );
        }
      }.bind(this), 200)
  },
});
