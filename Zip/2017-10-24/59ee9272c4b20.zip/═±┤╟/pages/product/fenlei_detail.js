// pages/product/fenlei_detail.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    productData:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // console.log("jtappid:" + jtappid)
    var openid = app.openid;
    console.log("openid:" + openid)
    this.setData({
      // store_logos: postsData.store_logos,
      // store_sliding: postsData.store_sliding,
      // store_GongGe: postsData.store_GongGe
    })
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/index_show?program_id=' + app.jtappid,
      method: 'get',
      data: {},
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        var productData = res.data.k1;
      
        console.log(JSON.stringify(res.data) + "成功++++++++++++++++++++++++++++++++++++")
     
        that.setData({
          productData: productData,
        
        });
        //endInitData
      },
      fail: function (e) {
        wx.showToast({
          title: '网络异常！',
          duration: 2000
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})