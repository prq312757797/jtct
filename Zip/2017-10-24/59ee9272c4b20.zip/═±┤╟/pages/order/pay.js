var app = getApp();
var shangping = '';
var array_id = ''
var pay_goods_id = ''
var zjpay_address = ''
var money = ''
var toastStr = ''
var roder_num = ''
// pages/order/downline.js
Page({
  data: {
    itemData: {},
    userId: 0,
    paytype: 'weixin',//0线下1微信
    remark: '',
    cartId: 0,
    shangping: '',
    addrId: 0,//收货地址//测试--
    btnDisabled: false,
    productData: [],
    address: {},
    fapiao_taitou: '',
    k0: '',
    total: 0,
    vprice: 0,
    vid: 0,
    addemt: 1,
    vou: []
  },
  onShow: function () {
    this.onLoad()
  },
  onLoad: function (options) {
    var that = this
    var zjpay = {}
    pay_goods_id = options.pay_goods_id
    toastStr = options.toastStr
    // 直接支付
    if (toastStr === undefined) {
      array_id = pay_goods_id
      wx.request({
        url: 'https://sz800800.cn/pg.php/Index/build_order',
        method: 'get',
        data: {
          array_id: pay_goods_id,
          openid: app._openid,
          program_id: app.jtappid
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          console.log("直接支付返回的data:" + JSON.stringify(res.data))

          if (res.data.k1 == null) {
            wx.showToast({
              title: '收货地址为空，请添加收货地址',
              duration: 2000
            });
            wx.navigateTo({
              // url: '../address/user-address/user-address',
              url: '../address/address',
            })
          }else{
          zjpay_address = res.data.k1.id
          money = res.data.k0
          that.setData({
            shangping: res.data.k2,
            k0: res.data.k0,
            address: res.data.k1
          })
          }
        }
      })
    } else {
      array_id = toastStr
      // 购物车支付
      zjpay = JSON.parse(options.shangping)
      zjpay_address = zjpay.k1.id
      money = zjpay.k0
      that.setData({
        shangping: zjpay.k2,
        address: zjpay.k1,
        k0: zjpay.k0,
      });
    }
    // this.loadProductDetail();
  },
  remarkInput: function (e) {
    this.setData({
      remark: e.detail.value,
    })
  },
  fapiao_taitouInput: function (e) {
    this.setData({
      fapiao_taitou: e.detail.value
    })
  },
  //确认付款
  createProductOrderByWX: function () {
    var that = this
    var from_id = wx.getStorageSync('from_id')
    wx.request({
      url: 'https://sz800800.cn/pg.php/Index/order_submin',
      data: {
        from_id: from_id,
        openid: app._openid,
        program_id: app.jtappid,
        array_id: array_id,
        shouhuo_id: zjpay_address,
        remark: this.data.remark,
        fapiao_taitou: this.data.fapiao_taitou
      },
      method: 'POST', 
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        if (res.data.status == 1) {
          roder_num = res.data.roder_num
          that.pay()
        }
      },
      fail: function () {
        // fail
        wx.showToast({
          title: '网络异常！err:wxpay',
          duration: 2000
        });
      }
    })
  },
  // 吊起支付接口
  pay: function () {
    var that = this;
    console.log('money:' + money)
    wx.request({
      url: 'https://sz800800.cn/Wxpay/make_order',
      data: {
        openid: app._openid,
        program_id: app.jtappid,
        data_total: money,//价钱
        order_num: roder_num
      },
      method: 'POST', 
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res)
        if (res.data.state == 1) {
          var pbj = res.data
          wx.requestPayment(
            {
              'timeStamp': pbj.timeStamp,
              'nonceStr': pbj.nonceStr.toString(),
              'package': pbj.package,
              'signType': 'MD5',
              'paySign': pbj.paySign,
              'success': function (res) {
                console.log("吊起支付:"+res)
                //支付成功以后返回给服务器支付结果
                  wx.request({
                    url: 'https://sz800800.cn/pg.php/Index/wancheng',
                    data: { order_num: roder_num },
                    method: 'post',
                    header: {
                      'content-type': 'application/x-www-form-urlencoded'
                    },
                    success(res) {
                      console.log("支付结果：" + JSON.stringify(res.data))
                      if (res.data.status == 0) {
                        wx.showToast({
                          title: '账户支付功能异常！',
                          duration: 2000
                        });
                      } else if (res.data.status == 1){
                        wx.showToast({
                          title: '支付成功！',
                          duration: 2000
                        });
                      }
                    }
                  })
                
              },
              'fail': function (res) {
                console.log("失败" + JSON.stringify(pbj.nonceStr))
              },
              'complete': function (res) { console.log("res" + JSON.stringify(res)) },

            })
        } else {
          wx.showToast({
            title: '支付失败！',
            duration: 2000
          });
        }
      }
    })

  },
  //线下支付
  createProductOrderByXX: function (e) {
    this.setData({
      paytype: 'cash',
    });
    wx.showToast({
      title: "线下支付开通中，敬请期待!",
      duration: 3000
    });
    return false;
    this.createProductOrder();
  },
  //确认订单
  createProductOrder: function () {
    this.setData({
      btnDisabled: false,
    })
  },
});