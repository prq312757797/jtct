//pages/utils/util  
var apiUrl = 'https://sz800800.cn/pg.php/';
function request(url, method, data, message, success, fail) {
  wx.showNavigationBarLoading()
  if (message != "") {
    wx.showLoading({
      title: message,
    })
  }
  wx.request({
    url: url,
    data: data,
    header: {
      'content-type': 'application/x-www-form-urlencoded'
    },
    method: method,
    success: function (res) {
      wx.hideNavigationBarLoading()
      if (message != "") {
        wx.hideLoading()
      }
      if (res.statusCode == 200) {
        success(res)
      } else {
        console.log("请求成功，返回信息：" + res.statusCode)
      }
    },
    fail: function (err) {
      wx.hideNavigationBarLoading()
      if (message != "") {
        wx.hideLoading()
      }
      console.log('请求失败：' + err)
    },
  })
}
module.exports = {
  request: request,
  apiUrl: apiUrl
}  